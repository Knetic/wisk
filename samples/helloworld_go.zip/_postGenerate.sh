#!/bin/bash

git init
git add . --all
git commit -a -m "Initial commit"
