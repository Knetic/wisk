package main

import (
  "fmt"
)

func main() {

  fmt.Printf("Hello, ${{=project.name=}}\n")
}
